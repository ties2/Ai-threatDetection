import React from 'react';
import { AlertTriangle, Shield, Activity, Radio } from 'lucide-react';
import ThreatDashboard from './components/ThreatDashboard';
import AlertsList from './components/AlertsList';
import NetworkMap from './components/NetworkMap';

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex items-center">
              <Shield className="h-8 w-8 text-indigo-600" />
              <span className="ml-2 text-xl font-semibold">Network Security Monitor</span>
            </div>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
        <div className="px-4 py-6 sm:px-0">
          <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
            <ThreatDashboard />
            <AlertsList />
          </div>
          <div className="mt-6">
            <NetworkMap />
          </div>
        </div>
      </main>
    </div>
  );
}

export default App;