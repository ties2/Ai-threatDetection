export interface Database {
  public: {
    Tables: {
      threats: {
        Row: {
          id: string;
          created_at: string;
          threat_score: number;
          status: string;
          event_count: number;
          source_ip: string | null;
          details: any;
          user_id: string;
        };
        Insert: {
          id?: string;
          created_at?: string;
          threat_score: number;
          status?: string;
          event_count?: number;
          source_ip?: string | null;
          details?: any;
          user_id: string;
        };
        Update: {
          id?: string;
          created_at?: string;
          threat_score?: number;
          status?: string;
          event_count?: number;
          source_ip?: string | null;
          details?: any;
          user_id?: string;
        };
      };
      alerts: {
        Row: {
          id: string;
          created_at: string;
          title: string;
          description: string | null;
          severity: string;
          status: string;
          threat_id: string | null;
          user_id: string;
        };
        Insert: {
          id?: string;
          created_at?: string;
          title: string;
          description?: string | null;
          severity?: string;
          status?: string;
          threat_id?: string | null;
          user_id: string;
        };
        Update: {
          id?: string;
          created_at?: string;
          title?: string;
          description?: string | null;
          severity?: string;
          status?: string;
          threat_id?: string | null;
          user_id?: string;
        };
      };
    };
  };
}