import React from 'react';
import { AlertTriangle, Shield, Info } from 'lucide-react';
import { useThreatStore } from '../store/threatStore';
import { format } from 'date-fns';

const AlertsList: React.FC = () => {
  const { alerts } = useThreatStore();

  const getAlertIcon = (severity: string) => {
    switch (severity.toLowerCase()) {
      case 'high':
        return <AlertTriangle className="h-5 w-5 text-red-500" />;
      case 'medium':
        return <Shield className="h-5 w-5 text-yellow-500" />;
      default:
        return <Info className="h-5 w-5 text-blue-500" />;
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-semibold mb-4">Active Alerts</h2>
      <div className="space-y-4">
        {alerts.map((alert) => (
          <div
            key={alert.id}
            className="flex items-start p-4 border rounded-lg hover:bg-gray-50"
          >
            <div className="flex-shrink-0">{getAlertIcon(alert.severity)}</div>
            <div className="ml-3">
              <h3 className="text-sm font-medium text-gray-900">{alert.title}</h3>
              <p className="mt-1 text-sm text-gray-500">{alert.description}</p>
              <p className="mt-1 text-xs text-gray-400">
                {format(new Date(alert.created_at), 'PPp')}
              </p>
            </div>
          </div>
        ))}
        {alerts.length === 0 && (
          <p className="text-center text-gray-500">No active alerts</p>
        )}
      </div>
    </div>
  );
};

export default AlertsList;