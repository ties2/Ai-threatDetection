import React, { useEffect, useRef } from 'react';
import { Radio } from 'lucide-react';

const NetworkMap: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Set canvas size
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;

    // Draw network visualization
    const drawNetwork = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Example: Draw some nodes and connections
      const nodes = [
        { x: 100, y: 100, label: 'Router 1' },
        { x: 300, y: 150, label: 'Router 2' },
        { x: 200, y: 250, label: 'Switch 1' },
      ];

      // Draw connections
      ctx.beginPath();
      ctx.strokeStyle = '#4F46E5';
      ctx.lineWidth = 2;
      nodes.forEach((node, i) => {
        if (i < nodes.length - 1) {
          ctx.moveTo(node.x, node.y);
          ctx.lineTo(nodes[i + 1].x, nodes[i + 1].y);
        }
      });
      ctx.stroke();

      // Draw nodes
      nodes.forEach(node => {
        ctx.beginPath();
        ctx.fillStyle = '#4F46E5';
        ctx.arc(node.x, node.y, 8, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#1F2937';
        ctx.font = '14px sans-serif';
        ctx.textAlign = 'center';
        ctx.fillText(node.label, node.x, node.y + 25);
      });
    };

    drawNetwork();

    // Redraw on resize
    const handleResize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
      drawNetwork();
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-semibold">Network Topology</h2>
        <div className="flex items-center space-x-2">
          <Radio className="h-5 w-5 text-indigo-600" />
          <span className="text-sm text-gray-600">Live View</span>
        </div>
      </div>
      <canvas
        ref={canvasRef}
        className="w-full h-[400px] border rounded-lg"
      />
    </div>
  );
};

export default NetworkMap;