import React, { useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Shield, AlertTriangle, Activity } from 'lucide-react';
import { useThreatStore } from '../store/threatStore';

const ThreatDashboard: React.FC = () => {
  const { threats, networkHealth, loading, fetchLatestThreats } = useThreatStore();

  useEffect(() => {
    fetchLatestThreats();
    
    // Set up real-time subscription
    const subscription = supabase
      .channel('threats')
      .on('postgres_changes', { 
        event: '*', 
        schema: 'public', 
        table: 'threats' 
      }, fetchLatestThreats)
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [fetchLatestThreats]);

  const activeThreats = threats.filter(t => t.status === 'active').length;
  const eventsPerHour = threats.length > 0 
    ? Math.round(threats.reduce((acc, t) => acc + t.event_count, 0) / threats.length)
    : 0;

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-xl font-semibold mb-4">Threat Overview</h2>
      
      <div className="grid grid-cols-3 gap-4 mb-6">
        <div className="p-4 bg-green-50 rounded-lg">
          <Shield className="h-6 w-6 text-green-600 mb-2" />
          <div className="text-2xl font-bold text-green-600">{networkHealth}%</div>
          <div className="text-sm text-green-600">Network Health</div>
        </div>
        
        <div className="p-4 bg-red-50 rounded-lg">
          <AlertTriangle className="h-6 w-6 text-red-600 mb-2" />
          <div className="text-2xl font-bold text-red-600">{activeThreats}</div>
          <div className="text-sm text-red-600">Active Threats</div>
        </div>
        
        <div className="p-4 bg-blue-50 rounded-lg">
          <Activity className="h-6 w-6 text-blue-600 mb-2" />
          <div className="text-2xl font-bold text-blue-600">{eventsPerHour}</div>
          <div className="text-sm text-blue-600">Events/Hour</div>
        </div>
      </div>

      <div className="h-64">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-indigo-600" />
          </div>
        ) : (
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={threats}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="created_at" 
                tickFormatter={(time) => new Date(time).toLocaleTimeString()} 
              />
              <YAxis />
              <Tooltip 
                labelFormatter={(label) => new Date(label).toLocaleString()}
              />
              <Line 
                type="monotone" 
                dataKey="threat_score" 
                stroke="#4F46E5" 
                strokeWidth={2} 
              />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
};

export default ThreatDashboard;