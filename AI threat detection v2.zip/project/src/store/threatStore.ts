import { create } from 'zustand';
import { supabase } from '../lib/supabase';

interface ThreatState {
  threats: any[];
  alerts: any[];
  networkHealth: number;
  loading: boolean;
  setThreats: (threats: any[]) => void;
  setAlerts: (alerts: any[]) => void;
  setNetworkHealth: (health: number) => void;
  fetchLatestThreats: () => Promise<void>;
}

export const useThreatStore = create<ThreatState>((set) => ({
  threats: [],
  alerts: [],
  networkHealth: 100,
  loading: false,
  setThreats: (threats) => set({ threats }),
  setAlerts: (alerts) => set({ alerts }),
  setNetworkHealth: (health) => set({ networkHealth: health }),
  fetchLatestThreats: async () => {
    set({ loading: true });
    const { data, error } = await supabase
      .from('threats')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);

    if (error) {
      console.error('Error fetching threats:', error);
    } else {
      set({ threats: data || [] });
    }
    set({ loading: false });
  },
}));