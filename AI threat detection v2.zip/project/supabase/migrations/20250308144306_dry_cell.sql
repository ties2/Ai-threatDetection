/*
  # Create tables for network security monitoring

  1. New Tables
    - `threats`
      - `id` (uuid, primary key)
      - `created_at` (timestamp)
      - `threat_score` (float)
      - `status` (text)
      - `event_count` (integer)
      - `source_ip` (text)
      - `details` (jsonb)
      
    - `alerts`
      - `id` (uuid, primary key)
      - `created_at` (timestamp)
      - `title` (text)
      - `description` (text)
      - `severity` (text)
      - `status` (text)
      - `threat_id` (uuid, foreign key)

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create threats table
CREATE TABLE IF NOT EXISTS threats (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  threat_score float NOT NULL,
  status text NOT NULL DEFAULT 'active',
  event_count integer DEFAULT 1,
  source_ip text,
  details jsonb DEFAULT '{}'::jsonb,
  user_id uuid REFERENCES auth.users(id)
);

-- Create alerts table
CREATE TABLE IF NOT EXISTS alerts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  created_at timestamptz DEFAULT now(),
  title text NOT NULL,
  description text,
  severity text NOT NULL DEFAULT 'low',
  status text NOT NULL DEFAULT 'active',
  threat_id uuid REFERENCES threats(id),
  user_id uuid REFERENCES auth.users(id)
);

-- Enable RLS
ALTER TABLE threats ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;

-- Create policies
CREATE POLICY "Users can read own threats"
  ON threats
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own threats"
  ON threats
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can read own alerts"
  ON alerts
  FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own alerts"
  ON alerts
  FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);